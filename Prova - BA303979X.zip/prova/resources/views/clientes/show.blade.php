@extends('clientes.layout')
  
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Exibir Clientes</h2>
            </div>
        </div>
    </div>
    <p>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nome :</strong>
                {{ $cliente->nome }}
            </div>
        </div>
		<p>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Informação :</strong>
                {{ $cliente->informacao }}
            </div>			
        </div>
		<p><p>
        <div class="pull-right">
            <a class="btn btn-primary" href="{{ route('clientes.index') }}"> Voltar</a>
        </div>		
    </div>
@endsection