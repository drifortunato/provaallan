  
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Exibir Clientes</h2>
            </div>
        </div>
    </div>
    <p>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nome :</strong>
                <?php echo e($cliente->nome); ?>

            </div>
        </div>
		<p>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Informação :</strong>
                <?php echo e($cliente->informacao); ?>

            </div>			
        </div>
		<p><p>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>"> Voltar</a>
        </div>		
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('clientes.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALUNO\prova\resources\views/clientes/show.blade.php ENDPATH**/ ?>